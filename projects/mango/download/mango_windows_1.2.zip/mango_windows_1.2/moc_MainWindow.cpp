/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created: Mon 4. Jul 17:46:06 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../MainWindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      43,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x0a,
      28,   11,   11,   11, 0x0a,
      51,   47,   11,   11, 0x0a,
      66,   11,   11,   11, 0x0a,
      84,   11,   11,   11, 0x0a,
      91,   11,   11,   11, 0x0a,
      99,   11,   11,   11, 0x0a,
     105,   11,   11,   11, 0x0a,
     124,   11,   11,   11, 0x0a,
     147,   11,   11,   11, 0x0a,
     163,   47,   11,   11, 0x0a,
     179,   11,   11,   11, 0x2a,
     194,  188,   11,   11, 0x0a,
     208,   11,   11,   11, 0x2a,
     219,   11,   11,   11, 0x0a,
     226,   11,   11,   11, 0x0a,
     236,   11,   11,   11, 0x0a,
     243,   11,   11,   11, 0x0a,
     252,   11,   11,   11, 0x0a,
     259,   47,   11,   11, 0x0a,
     277,   11,   11,   11, 0x2a,
     288,  188,   11,   11, 0x0a,
     314,  304,   11,   11, 0x0a,
     335,   47,   11,   11, 0x0a,
     351,   11,   11,   11, 0x0a,
     364,   11,   11,   11, 0x0a,
     371,   11,   11,   11, 0x0a,
     380,   11,   11,   11, 0x0a,
     397,   11,   11,   11, 0x0a,
     415,   11,   11,   11, 0x0a,
     439,   11,   11,   11, 0x0a,
     451,   11,   11,   11, 0x0a,
     466,   11,   11,   11, 0x08,
     490,  478,   11,   11, 0x08,
     506,  503,   11,   11, 0x08,
     548,  525,   11,   11, 0x08,
     582,   11,   11,   11, 0x08,
     590,   11,   11,   11, 0x08,
     615,  607,   11,   11, 0x08,
     648,   11,   11,   11, 0x08,
     667,   11,   11,   11, 0x08,
     701,  684,   11,   11, 0x08,
     734,  728,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0getSourceCode()\0"
    "toggleFullScreen()\0url\0openLink(QUrl)\0"
    "saveCurrentPage()\0copy()\0paste()\0cut()\0"
    "selectAllWebView()\0toggleWindowFindText()\0"
    "highlightText()\0newTab(QString)\0"
    "newTab()\0index\0closeTab(int)\0closeTab()\0"
    "back()\0forward()\0stop()\0reload()\0"
    "home()\0loadPage(QString)\0loadPage()\0"
    "switchTabs(int)\0fullTitle\0"
    "changeTitle(QString)\0changeUrl(QUrl)\0"
    "changeIcon()\0zoom()\0unZoom()\0"
    "setDefaultZoom()\0showPreferences()\0"
    "togglePrivateBrowsing()\0printPage()\0"
    "printPreview()\0loadBegin()\0pourcentage\0"
    "loading(int)\0ok\0loadComplete(bool)\0"
    "link,title,textContent\0"
    "showLink(QString,QString,QString)\0"
    "about()\0showSourceCode()\0reponse\0"
    "downloadFileAuto(QNetworkReply*)\0"
    "downloadFinished()\0cancelDownload()\0"
    "downloaded,total\0downloading(qint64,qint64)\0"
    "reply\0checkError(QNetworkReply*)\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: getSourceCode(); break;
        case 1: toggleFullScreen(); break;
        case 2: openLink((*reinterpret_cast< QUrl(*)>(_a[1]))); break;
        case 3: saveCurrentPage(); break;
        case 4: copy(); break;
        case 5: paste(); break;
        case 6: cut(); break;
        case 7: selectAllWebView(); break;
        case 8: toggleWindowFindText(); break;
        case 9: highlightText(); break;
        case 10: newTab((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: newTab(); break;
        case 12: closeTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: closeTab(); break;
        case 14: back(); break;
        case 15: forward(); break;
        case 16: stop(); break;
        case 17: reload(); break;
        case 18: home(); break;
        case 19: loadPage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 20: loadPage(); break;
        case 21: switchTabs((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: changeTitle((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 23: changeUrl((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 24: changeIcon(); break;
        case 25: zoom(); break;
        case 26: unZoom(); break;
        case 27: setDefaultZoom(); break;
        case 28: showPreferences(); break;
        case 29: togglePrivateBrowsing(); break;
        case 30: printPage(); break;
        case 31: printPreview(); break;
        case 32: loadBegin(); break;
        case 33: loading((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: loadComplete((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 35: showLink((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 36: about(); break;
        case 37: showSourceCode(); break;
        case 38: downloadFileAuto((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 39: downloadFinished(); break;
        case 40: cancelDownload(); break;
        case 41: downloading((*reinterpret_cast< qint64(*)>(_a[1])),(*reinterpret_cast< qint64(*)>(_a[2]))); break;
        case 42: checkError((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 43;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
